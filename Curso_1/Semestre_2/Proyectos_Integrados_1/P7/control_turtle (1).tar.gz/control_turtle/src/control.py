#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
import numpy as np
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
import math

class TurtlebotController:
    def __init__(self):
        rospy.init_node('turtlebot_controller', anonymous=True)

        self.obstacle_threshold = 1.5
        self.turn_threshold = 1.3
        self.forward_speed = 0.95
        self.turn_speed_max = 1.7
        self.kp_angular = 2.0
        self.min_arc_readings = 5
        self.exit_turn_front_clearance = self.obstacle_threshold * 1.1
        self.min_escape_width_ratio = 0.8

        self.target_angle_when_turning = 0.0
        self.current_twist = Twist()
        self.laser_data_received = False
        self.latest_scan = None
        self.is_actively_turning = False
        self.current_state_info = "Inicializando"

        self.cmd_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=1)
        self.scan_sub = rospy.Subscriber("/kobuki/laser/scan", LaserScan, self.scan_callback)

        rospy.loginfo("Turtlebot Controller Nodo Inicializado.")
        rospy.loginfo("Parameters: Obstaculo Umbral={:.2f}m, Girar Umbral={:.2f}m, SalidaFontralDespejada={:.2f}m, RatioMinEscape={:.1f}, Adelante Vel={:.2f}m/s, Girar Vel={:.2f}rad/s, Kp={:.1f}".format(
                      self.obstacle_threshold, self.turn_threshold, self.exit_turn_front_clearance, self.min_escape_width_ratio,
                      self.forward_speed, self.turn_speed_max, self.kp_angular))

    def scan_callback(self, msg):
        self.latest_scan = msg
        self.laser_data_received = True

    def find_open_arcs(self, scan):
        if scan is None: return []
        ranges = np.array(scan.ranges)
        max_safe_range = scan.range_max if scan.range_max > self.obstacle_threshold else self.obstacle_threshold + 1.0
        ranges[np.isinf(ranges)] = max_safe_range
        ranges[np.isnan(ranges)] = 0.0
        open_arcs = []
        in_arc = False
        arc_start_idx = 0
        for i, dist in enumerate(ranges):
            is_clear = dist > self.obstacle_threshold
            if is_clear and not in_arc:
                in_arc = True
                arc_start_idx = i
            elif (not is_clear or i == len(ranges) - 1) and in_arc:
                in_arc = False
                arc_end_idx = i if is_clear else i - 1
                width_indices = arc_end_idx - arc_start_idx + 1
                if width_indices >= self.min_arc_readings:
                    arc_info = self._calculate_arc_properties(scan, ranges, arc_start_idx, arc_end_idx, width_indices)
                    if arc_info:
                        open_arcs.append(arc_info)
        return open_arcs

    def _calculate_arc_properties(self, scan, ranges, start_idx, end_idx, width_indices):
        try:
            angle_start = scan.angle_min + start_idx * scan.angle_increment
            angle_end = scan.angle_min + end_idx * scan.angle_increment
            center_angle = math.atan2(math.sin(angle_start)+math.sin(angle_end), math.cos(angle_start)+math.cos(angle_end))
            min_dist_in_arc = np.min(ranges[start_idx : end_idx + 1])
            return (start_idx, end_idx, center_angle, min_dist_in_arc, width_indices)
        except Exception as e:
            rospy.logwarn("Error al calcular las propiedades del arco: {}".format(e))
            return None

    def find_best_arc_to_escape(self, arcs):
        """
        Encuentra el arco SUFICIENTEMENTE ANCHO cuyo centro esté MÁS CERCA
        del ángulo 0 (frente del robot).
        """
        if not arcs:
            rospy.logwarn("find_best_arc_to_escape: No se proporcionan arcos.")
            return None

        try:
            max_width = 0
            for arc in arcs:
                current_width = arc[4] if len(arc) > 4 and isinstance(arc[4], (int, float)) else 0
                if current_width > max_width:
                    max_width = current_width

            if max_width < self.min_arc_readings:
                rospy.logwarn("find_best_arc_to_escape: Anchura máxima ({:.0f}) es inferior a las lecturas mínimas ({}). Sin arco viable.".format(max_width, self.min_arc_readings))
                return None

            min_required_width = max_width * self.min_escape_width_ratio
            sufficiently_wide_arcs = [arc for arc in arcs if len(arc) > 4 and isinstance(arc[4], (int, float)) and arc[4] >= min_required_width]

            if not sufficiently_wide_arcs:
                rospy.logwarn("find_best_arc_to_escape: Sin arcos que cumplan la relación de ancho {:.1f} (ancho_min={:.0f}). Retroceso al mayor ancho.".format(self.min_escape_width_ratio, min_required_width))
                widest_arc = max(arcs, key=lambda arc: arc[4] if len(arc) > 4 and isinstance(arc[4], (int, float)) else 0)
                if widest_arc[4] < self.min_arc_readings:
                    rospy.logwarn("find_best_arc_to_escape: El arco más ancho del retroceso sigue siendo demasiado estrecho.")
                    return None
                return widest_arc

            best_arc = min(sufficiently_wide_arcs, key=lambda arc: abs(arc[2]) if len(arc) > 2 and isinstance(arc[2], (int, float)) else float('inf'))
            rospy.loginfo("find_best_arc_to_escape: Encontrado {} arcos suficientemente anchos (Ancho_min={:.0f}). Elegir arco centrado en {:.1f}deg.".format(
               len(sufficiently_wide_arcs), min_required_width, math.degrees(best_arc[2])))
            return best_arc

        except Exception as e:
             rospy.logerr("Error en find_best_arc_to_escape: {}".format(e), exc_info=True)
             return None

    def get_scan_index(self, scan, angle_rad):
        if scan is None or scan.angle_increment == 0: return None
        relative_angle = self.normalize_angle(angle_rad)
        if relative_angle < scan.angle_min - 1e-4: return 0
        if relative_angle > scan.angle_max + 1e-4: return len(scan.ranges) - 1
        index = int((relative_angle - scan.angle_min) / scan.angle_increment)
        index = max(0, min(index, len(scan.ranges) - 1))
        return index

    def check_target_arc_clearance(self, scan, target_angle_rad):
        if scan is None: return 0.0
        target_index = self.get_scan_index(scan, target_angle_rad)
        if target_index is None: return 0.0
        index_offset = 3
        start_check_idx = max(0, target_index - index_offset)
        end_check_idx = min(len(scan.ranges) - 1, target_index + index_offset)
        if start_check_idx > end_check_idx:
             if 0 <= target_index < len(scan.ranges): check_range_indices = [target_index]
             else: return 0.0
        else: check_range_indices = range(start_check_idx, end_check_idx + 1)
        if not check_range_indices: return 0.0
        ranges_target_arc = np.array([scan.ranges[i] for i in check_range_indices])
        safe_max_range = scan.range_max if np.isfinite(scan.range_max) else 10.0
        ranges_target_arc[np.isinf(ranges_target_arc)] = safe_max_range
        ranges_target_arc[np.isnan(ranges_target_arc)] = 0.0
        return np.min(ranges_target_arc) if len(ranges_target_arc) > 0 else 0.0

    def check_front_clearance(self, scan):
        return self.check_target_arc_clearance(scan, 0.0)

    def run(self):
        """Bucle principal de control."""
        rate = rospy.Rate(10)

        while not rospy.is_shutdown():
            if not self.laser_data_received or self.latest_scan is None:
                rate.sleep()
                continue

            scan_to_process = self.latest_scan
            self.laser_data_received = False

            min_dist_ahead = self.check_front_clearance(scan_to_process)
            needs_evasive_turn_request = min_dist_ahead <= self.turn_threshold

            if self.is_actively_turning:
                error_angular = self.normalize_angle(self.target_angle_when_turning)
                turn_command = self.kp_angular * error_angular
                self.current_twist.linear.x = 0.0
                self.current_twist.angular.z = np.clip(turn_command, -self.turn_speed_max, self.turn_speed_max)

                current_front_clearance = self.check_front_clearance(scan_to_process)

                rospy.loginfo("Estado: Girando (Activado). Objetivo original: {:.1f}grad, CmdZ: {:.2f}. Espacio libre frontal actual: {:.2f}m (Req Salida: {:.2f}m)".format(
                    math.degrees(self.target_angle_when_turning), self.current_twist.angular.z,
                    current_front_clearance, self.exit_turn_front_clearance))

                if current_front_clearance > self.exit_turn_front_clearance:
                    self.current_state_info = "Hacia adelante (Giro Completado)"
                    rospy.loginfo(self.current_state_info + ". El frente está limpio.")
                    self.is_actively_turning = False
                    self.target_angle_when_turning = 0.0
                    self.current_twist.angular.z = 0.0

            elif needs_evasive_turn_request:
                self.current_state_info = "Girando (Obstaculo Detectado)"
                rospy.logwarn(self.current_state_info + ". Distancia adelante: {:.2f}m <= {:.2f}m".format(min_dist_ahead, self.turn_threshold))

                open_arcs = self.find_open_arcs(scan_to_process)
                escape_arc = self.find_best_arc_to_escape(open_arcs)

                if escape_arc:
                    self.target_angle_when_turning = self.normalize_angle(escape_arc[2])
                    #rospy.loginfo("Encontrado arco de escape. Guardamos el angulo objetivo: {:.1f}grad (...)".format(math.degrees(self.target_angle_when_turning))) Depuracion

                    self.is_actively_turning = True
                    error_angular = self.target_angle_when_turning
                    turn_command = self.kp_angular * error_angular
                    self.current_twist.linear.x = 0.0
                    self.current_twist.angular.z = np.clip(turn_command, -self.turn_speed_max, self.turn_speed_max)
                else:
                    self.current_state_info = "Bloqueado - Parando"
                    rospy.logerr(self.current_state_info + ". No se ha encontrado ruta de escape")
                    self.is_actively_turning = False
                    self.target_angle_when_turning = 0.0
                    self.current_twist.linear.x = 0.0
                    self.current_twist.angular.z = 0.0


            else:
                #self.current_state_info = "Avanzar (Camino libre)" Depuracion
                self.is_actively_turning = False
                self.current_twist.linear.x = self.forward_speed
                self.current_twist.angular.z = 0.0
                #rospy.loginfo(self.current_state_info + ". Dist adelante: {:.2f}m. CmdZ: {:.2f}".format(min_dist_ahead, self.current_twist.angular.z)) Depuracion


            self.cmd_pub.publish(self.current_twist)
            rate.sleep()

        rospy.loginfo("Apagando el nodo. Parando robot.")
        self.cmd_pub.publish(Twist())

    def normalize_angle(self, angle):
        while angle > math.pi: angle -= 2.0 * math.pi
        while angle < -math.pi: angle += 2.0 * math.pi
        return angle

if __name__ == '__main__':
    try:
        controller = TurtlebotController()
        controller.run()
    except rospy.ROSInterruptException:
        rospy.loginfo("Nodo terminado por ROS.")
    except Exception as e:
        rospy.logerr("Un error inesperado ha ocurrido en el main loop principal: {}".format(e), exc_info=True)
    finally:
        try:
           final_twist = Twist()
           pub = rospy.Publisher("/cmd_vel", Twist, queue_size=1, latch=True)
           pub.publish(final_twist)
           rospy.sleep(0.2)
           rospy.loginfo("Comando publicado de parada final.")
        except Exception as pub_err:
            rospy.logerr("No se ha podido publicar el comando de parada: {}".format(pub_err))