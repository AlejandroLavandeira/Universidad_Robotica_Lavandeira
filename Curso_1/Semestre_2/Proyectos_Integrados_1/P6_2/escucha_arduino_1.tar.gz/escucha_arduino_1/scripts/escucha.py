#!/usr/bin/env python

import rospy
from std_msgs.msg import Int32
def callback(msg):
	print (msg.data)
def integer_subscriber():
	rospy.init_node('suscriptor_victor')
	rospy.Subscriber('sensor',Int32,callback)
	rospy.spin()
if __name__ == "__main__":
	try:
 		integer_subscriber()
 	except rospy.ROSInterruptException:
 		pass
