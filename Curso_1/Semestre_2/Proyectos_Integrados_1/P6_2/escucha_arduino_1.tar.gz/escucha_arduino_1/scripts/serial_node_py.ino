#include <ros.h>
#include <std_msgs/Int32.h>

const int Echo=5;
const int Trigger=6;

ros::NodeHandle nh;
std_msgs::Int32 distancia;
ros::Publisher publicador_distancia("sensor",&distancia)

void setup(){
 Serial.begin(9600);
 pinMode(Trigger,OUTPUT);
 pinMode(Echo,INPUT);
 digitalWrite(Trigger,LOW);
 
 nh.initNode();
 nd.advertise(publicador_distancia);
}

void loop(){
 long t;
 long d;

 digitalWrite(Trigger,HIGH);
 delayMicroseconds(10);
 digitalWrite(Trigger,LOW);

 t=pulseIn(Echo,HIGH);
 d=t/59;

 distancia.data = d;
 publicador_distancia.publish(&distancia);
 nh.spinOnce();

 Serial.print("Distancia: ");
 Serial.print(d);
 Serial.println("cm");

 delay(100);
}
